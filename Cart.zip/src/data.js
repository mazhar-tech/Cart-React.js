const list = [
    {
    id: 1,
    name: "Apple Juice",
    volume: 250,
    inStock: true,
    quantity: 0,
    price: 2.99,
    img: 'https://media.naheed.pk/catalog/product/cache/ed9f5ebe2a117625f6cd6336daddd764/1/2/1219483-1.jpg',
    },
    {
    id: 1,
    name: "Grapes Juice",
    volume: 500,
    inStock: false,
    quantity: 0,
    price: 3.19,
    img: 'https://media.naheed.pk/catalog/product/cache/49dcd5d85f0fa4d590e132d0368d8132/1/0/1033730-1.jpg',
    }
    ]

    export default list;